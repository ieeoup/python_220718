# demo.py 

print("hello VS Code")
